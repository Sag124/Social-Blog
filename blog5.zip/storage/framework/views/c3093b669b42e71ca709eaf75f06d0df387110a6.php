<?php $__env->startSection('title','| Create'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <h1>Contact Me
      <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
      </h1>
      <hr>
      <?php echo Form::open(array('route' => 'contact.store')); ?>

    
      <?php echo e(Form::label('email', 'Email:')); ?>

      <?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>


      <?php echo e(Form::label('subject', 'Subject:')); ?>

      <?php echo e(Form::text('subject', null, array('class' => 'form-control', 'required' => '', 'minlength' => '5', 'maxlength' => '255' ))); ?>


      <?php echo e(Form::label('body', 'Body:')); ?>

      <?php echo e(Form::textarea('body', null, ['class' => 'form-control'])); ?>


      &nbsp;
      
      <?php echo e(Form::submit('Submit', ['class' => 'btn btn-success btn-block'])); ?>


      <?php echo Form::close(); ?>

    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>