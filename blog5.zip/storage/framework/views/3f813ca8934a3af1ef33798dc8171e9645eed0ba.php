<?php $__env->startSection('title', '| Welcome Page'); ?>
<?php $__env->startSection('content'); ?>
      <div class="row">
        <div class="col-md-12">
          <div class="jumbotron">
            <h1 class="h1-sp">Welcome to My Blog!</h1>
            <p class="lead">Thank you so much for visiting. This is my test website built with Laravel. Please read my popular post!</p>
            <p><a class="btn btn-success btn-lg" href="blog/pointers">Popular Post</a></p>
          </div>
        </div>
      </div>
      <!-- end of header .row -->

      <div class="row">
        <div class="col-md-7">
          
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

          <div class="post">
            <h3><?php echo e($post->title); ?></h3>
            <p><?php echo e(substr(strip_tags($post->body), 0,50)); ?><?php echo e(strlen(strip_tags($post->body))>50 ? "..." : ""); ?></p>
            <a href="blog/<?php echo e($post->slug); ?>" class="btn btn-primary">Read More</a>
          </div>
          <hr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </div>

        <div class="col-md-4">
          <h2 class="text-center">Current Updates!</h2>          
          
          <div class="list-group">
          <marquee behavior="scroll" direction="up" bgcolor="white" height="200px">
          <a href="#" class="list-group-item list-group-item-success">Recently 200 members registered in our website</a>
          <a href="#" class="list-group-item list-group-item-info">Blog posts are increasing day by day!</a>
          <a href="#" class="list-group-item list-group-item-warning">Blog post user interface has been modified</a>
          <a href="#" class="list-group-item list-group-item-danger">Please log in to view your updates</a>
          </marquee>
          </div>
          
      <div class="row">
        <div class="col-md-2 col-md-offset-2">
           <blockquote>Time is precious Dont waste it.
          <footer>So Keep Posting!</footer>
          </blockquote>
        </div>
        </div>
      </div>
      </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>