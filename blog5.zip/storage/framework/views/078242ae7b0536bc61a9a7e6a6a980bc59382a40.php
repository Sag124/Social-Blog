<?php $__env->startSection('title', '| View All Tags'); ?>

<?php $__env->startSection('content'); ?>

		<div class="row">
		<div class="col-md-8">
			<h1>All Tags</h1>
		</div>
		<div class="col-md-4">
			<div class="well">
			<?php echo Form::open(array('route' => 'tags.store')); ?>

	
		<?php echo e(Form::label('name','Name:')); ?>

		<?php echo e(Form::text('name', null,['class' => 'form-control'])); ?>	
			<p></p>
		<?php echo e(Form::submit('Create New Tag',['class' => 'btn btn-md btn-success center-block'])); ?>


		<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
	
	
		<div class="row">
		<div class="col-md-12">
		<table class="table table-striped">
			<thead>
			<th>#</th>
			<th>Name</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				
					<tr>
						<th> <?php echo e($tag->id); ?> </th>
						<th> <a href="<?php echo e(route('tags.show',$tag->id)); ?>"><?php echo e($tag->name); ?></a></th>
						<td><a href="<?php echo e(route('tags.show',$tag->id)); ?>" class="btn btn-default btn-sm">View</a> <a href="<?php echo e(route('tags.edit', $tag->id)); ?>" class="btn btn-default btn-sm">Edit</a><a href="<?php echo e(route('tags.destroy', $tag->id)); ?>" class="btn btn-default btn-sm">Delete</a></td>
					</tr>
		
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
		</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>