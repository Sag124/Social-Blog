<?php $__env->startSection('title', '| Category Create'); ?>

<?php $__env->startSection('content'); ?>

		<div class="row">	
		<div class="col-md-8 col-md-offset-1">
		<?php echo Form::open(array('route' => 'category.store')); ?>

	
		<?php echo e(Form::label('name','Name:')); ?>

		<?php echo e(Form::text('name', null,['class' => 'form-control'])); ?>	
			<p>&nbsp;</p>
		<?php echo e(Form::submit('Create New Category',['class' => 'btn btn-md btn-success center-block'])); ?>


		<?php echo Form::close(); ?>

		</div>
		</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>