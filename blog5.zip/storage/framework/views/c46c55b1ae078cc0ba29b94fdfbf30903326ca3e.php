<?php $__env->startSection('title', '| Category Page'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-8">
			<h1>All categories</h1>
		</div>
		<div class="col-md-4">
			<div class="well">
			<?php echo Form::open(array('route' => 'category.store')); ?>

	
		<?php echo e(Form::label('name','Name:')); ?>

		<?php echo e(Form::text('name', null,['class' => 'form-control'])); ?>	
			<p></p>
		<?php echo e(Form::submit('Create New Category',['class' => 'btn btn-md btn-success center-block'])); ?>


		<?php echo Form::close(); ?>

			<!--<a href="<?php echo e(route('category.store')); ?>" class="btn btn-primary btn-block">Create Category</a>-->
			</div>
		</div>
	</div>
		<div class="row">
			<div class="col-md-12">
				<table class="table table-hover">
					<thead>
						<th>#</th>
						<th>Name</th>
						<th>Created At</th>
						<th>Updated At</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr>
						<td> <?php echo e($category->id); ?> </td>
						<td> <?php echo e($category->name); ?> </td>
						<td> <?php echo e($category->created_at); ?> </td>
						<td> <?php echo e($category->updated_at); ?> </td>
						<td><a href="<?php echo e(route('category.show',$category->id)); ?>" class="btn btn-default btn-sm">View</a> <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="btn btn-default btn-sm">Edit</a></td>
						</tr>	
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>