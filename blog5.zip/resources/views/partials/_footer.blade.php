  <hr>

    <p class="text-center">Copyrights reserved - Laravel 5.3</p>
 