@extends('main')
@section('title', '| About')
@section('content')
      <div class="row">
        <div class="col-md-12">
          <img src="images.jpg" class="img-circle" alt="Responsive image">
          <p class="lead text-center">Currently learning Laravel and in Love with it!</p>
        </div>
      </div>
@endsection